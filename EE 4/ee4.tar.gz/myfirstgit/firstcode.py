import sys
import time
import lib_book as lb

print("Good day & hello Harshini")
lb.types("Electrical")
